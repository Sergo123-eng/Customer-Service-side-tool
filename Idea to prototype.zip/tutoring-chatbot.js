/* MC Tutoring Assistant — clickable demo
   Drives the exact conversation flow from the proposal.
   Demo data only; the production version reads availability from
   Middlesex College's live WCONLINE schedule. */
(function () {
  "use strict";

  var SUBJECTS = ["Pre-Calculus", "Calculus I", "Biology", "Chemistry", "English Comp"];
  var DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  var SLOTS = {
    Morning: ["9:00 AM", "10:00 AM", "11:00 AM"],
    Afternoon: ["12:30 PM", "1:30 PM", "2:30 PM", "3:30 PM"]
  };
  // For the demo: who is open at the chosen slot vs. busy.
  var TUTORS = ["Sergo Bekhit", "Katie", "Komal"];
  var OPEN_TUTORS = ["Sergo Bekhit", "Katie"]; // the rest are "busy" to show the fail branch

  var state = {};
  var thread, composer;

  function $(sel, root) { return (root || document).querySelector(sel); }
  function el(tag, cls, html) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (html != null) n.innerHTML = html;
    return n;
  }
  function scrollDown() { thread.scrollTop = thread.scrollHeight; }

  function addUser(text) {
    var row = el("div", "msg-row user");
    row.appendChild(el("div", "bubble user", escapeHtml(text)));
    thread.appendChild(row);
    scrollDown();
  }
  function addBot(html, cb) {
    typing(function () {
      var row = el("div", "msg-row bot");
      row.appendChild(el("div", "avatar", "MC"));
      row.appendChild(el("div", "bubble bot", html));
      thread.appendChild(row);
      scrollDown();
      if (cb) cb();
    });
  }
  function addSystem(html) {
    var row = el("div", "msg-row sys");
    row.appendChild(el("div", "sys-line", html));
    thread.appendChild(row);
    scrollDown();
  }
  function typing(done) {
    var row = el("div", "msg-row bot");
    row.appendChild(el("div", "avatar", "MC"));
    var b = el("div", "bubble bot typing", "<span></span><span></span><span></span>");
    row.appendChild(b);
    thread.appendChild(row);
    scrollDown();
    setTimeout(function () { row.remove(); done(); }, 620);
  }

  function clearComposer() { composer.innerHTML = ""; }
  function chips(items, onPick, opts) {
    clearComposer();
    opts = opts || {};
    var wrap = el("div", "chips" + (opts.stack ? " stack" : ""));
    items.forEach(function (it) {
      var label = typeof it === "string" ? it : it.label;
      var value = typeof it === "string" ? it : (it.value != null ? it.value : it.label);
      var b = el("button", "chip" + (it.kind ? " " + it.kind : ""), escapeHtml(label));
      b.addEventListener("click", function () { onPick(value, label); });
      wrap.appendChild(b);
    });
    composer.appendChild(wrap);
  }
  function textInput(placeholder, onSubmit, suggestChips) {
    clearComposer();
    if (suggestChips) {
      var sug = el("div", "chips");
      suggestChips.forEach(function (name) {
        var b = el("button", "chip ghost", escapeHtml(name));
        b.addEventListener("click", function () { onSubmit(name); });
        sug.appendChild(b);
      });
      composer.appendChild(sug);
    }
    var form = el("form", "composer-form");
    var input = el("input", "composer-input");
    input.type = "text";
    input.placeholder = placeholder;
    input.autocomplete = "off";
    var send = el("button", "send-btn", "Send");
    send.type = "submit";
    form.appendChild(input);
    form.appendChild(send);
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      var v = input.value.trim();
      if (v) onSubmit(v);
    });
    composer.appendChild(form);
    setTimeout(function () { input.focus(); }, 50);
  }

  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  /* ---------- Flow ---------- */
  function start() {
    state = {};
    thread.innerHTML = "";
    composer.innerHTML = "";
    addBot(
      "Hi! I'm the <strong>MC Tutoring Assistant</strong>. I can book a tutoring appointment for you in under a minute.<br><br>What subject do you need help with?",
      askSubject
    );
  }
  function askSubject() {
    chips(SUBJECTS, function (v) {
      addUser(v);
      state.subject = v;
      askDay();
    });
  }
  function askDay() {
    addBot("Great — <strong>" + escapeHtml(state.subject) + "</strong>. Which day works best for you?", function () {
      chips(DAYS, function (v) {
        addUser(v);
        state.day = v;
        askMode();
      });
    });
  }
  function askMode() {
    addBot("Would you like your session <strong>online</strong> or <strong>in person</strong>?", function () {
      chips(["Online", "In person"], function (v) {
        addUser(v);
        state.mode = v;
        askDaypart();
      });
    });
  }
  function askDaypart() {
    addBot("What time of day suits you?", function () {
      chips(["Morning", "Afternoon"], function (v) {
        addUser(v);
        state.daypart = v;
        askTime();
      });
    });
  }
  function askTime() {
    addBot("Here's what's open " + escapeHtml(state.day) + " " + escapeHtml(state.daypart.toLowerCase()) + ". Pick a time:", function () {
      chips(SLOTS[state.daypart], function (v) {
        addUser(v);
        state.time = v;
        askTutorChoice();
      });
    });
  }
  function askTutorChoice() {
    addBot("Do you want a <strong>specific tutor</strong>, or should I find the first one available?", function () {
      chips([
        { label: "Pick a specific tutor", value: "yes" },
        { label: "Find any available tutor", value: "no" }
      ], function (v) {
        if (v === "yes") {
          addUser("I'd like a specific tutor");
          askTutorName();
        } else {
          addUser("Find any available tutor");
          findAnyTutor();
        }
      });
    });
  }
  function askTutorName() {
    addBot("Sure — type the tutor's name (or tap one below).", function () {
      textInput("e.g. Sergo Bekhit", function (name) {
        addUser(name);
        state.requestedTutor = name;
        checkTutor(name);
      }, TUTORS);
    });
  }
  function findAnyTutor() {
    connecting(function () {
      var tutor = OPEN_TUTORS[0];
      state.tutor = tutor;
      addBot("I found <strong>" + escapeHtml(tutor) + "</strong> available " + summaryLine() + ".", confirmStep);
    });
  }
  function checkTutor(name) {
    connecting(function () {
      var match = matchTutor(name);
      if (match && OPEN_TUTORS.indexOf(match) !== -1) {
        state.tutor = match;
        addBot("Good news — <strong>" + escapeHtml(match) + "</strong> is available " + summaryLine() + ".", confirmStep);
      } else if (match) {
        // known tutor but busy at this slot
        addBot(
          "<strong>" + escapeHtml(match) + "</strong> isn't available " + escapeHtml(state.day) + " at " + escapeHtml(state.time) +
          ". You can try a different time or a different tutor.<br><br>Open at this time: <strong>" + OPEN_TUTORS.join(", ") + "</strong>.",
          function () {
            chips([
              { label: "Different time", value: "time" },
              { label: "Different tutor", value: "tutor" },
              { label: "Book " + OPEN_TUTORS[0], value: "book", kind: "primary" }
            ], function (v) {
              if (v === "time") { addUser("Different time"); askDaypart(); }
              else if (v === "tutor") { addUser("Different tutor"); askTutorName(); }
              else { addUser("Book " + OPEN_TUTORS[0]); state.tutor = OPEN_TUTORS[0]; confirmStep(); }
            });
          }
        );
      } else {
        addBot(
          "I couldn't find a Pre-Calculus tutor by that name. The tutors on this schedule are:<br><strong>" +
          TUTORS.join(", ") + "</strong>. Who would you like?",
          function () { textInput("Type a tutor's name", function (n) { addUser(n); checkTutor(n); }, TUTORS); }
        );
      }
    });
  }
  function matchTutor(name) {
    var q = name.toLowerCase();
    for (var i = 0; i < TUTORS.length; i++) {
      var parts = TUTORS[i].toLowerCase().split(" ");
      if (q === TUTORS[i].toLowerCase() || parts.indexOf(q) !== -1 ||
          parts.some(function (p) { return q.indexOf(p) !== -1; })) {
        return TUTORS[i];
      }
    }
    return null;
  }
  function connecting(done) {
    addSystem('<span class="spinner"></span> Connecting to Middlesex College WCONLINE schedule…');
    setTimeout(done, 1150);
  }
  function summaryLine() {
    return escapeHtml(state.day) + " at " + escapeHtml(state.time) + " (" + escapeHtml(state.mode) + ")";
  }
  function confirmStep() {
    var card =
      '<div class="confirm-card">' +
      '<div class="cc-title">Review your appointment</div>' +
      row("Subject", state.subject) +
      row("Tutor", state.tutor) +
      row("Day", state.day) +
      row("Time", state.time) +
      row("Format", state.mode) +
      "</div>";
    addBot(card + "Shall I book it?", function () {
      chips([
        { label: "Confirm booking", value: "confirm", kind: "primary" },
        { label: "Change time", value: "change" }
      ], function (v) {
        if (v === "confirm") { addUser("Confirm booking"); book(); }
        else { addUser("Change time"); askDaypart(); }
      });
    });
  }
  function row(k, v) {
    return '<div class="cc-row"><span>' + k + "</span><strong>" + escapeHtml(v || "—") + "</strong></div>";
  }
  function book() {
    addSystem('<span class="spinner"></span> Creating appointment in WCONLINE…');
    setTimeout(function () {
      var conf = "MC-" + Math.floor(100000 + Math.random() * 899999);
      addBot(
        '<div class="success-card">' +
        '<div class="sc-check">✓</div>' +
        '<div class="sc-title">You\'re booked!</div>' +
        '<div class="sc-sub">' + escapeHtml(state.subject) + " with " + escapeHtml(state.tutor) + "<br>" +
        escapeHtml(state.day) + " · " + escapeHtml(state.time) + " · " + escapeHtml(state.mode) + "</div>" +
        '<div class="sc-conf">Confirmation ' + conf + "</div>" +
        "</div>" +
        "A confirmation email is on its way. See you then!",
        function () {
          clearComposer();
          chips([{ label: "Start over", value: "restart", kind: "ghost" }], function () { start(); });
        }
      );
    }, 1150);
  }

  /* ---------- Mount ---------- */
  function mount() {
    var host = document.getElementById("chat-demo");
    if (!host) return;
    host.innerHTML =
      '<div class="phone">' +
      '<div class="phone-head">' +
      '<div class="ph-avatar">MC</div>' +
      '<div class="ph-meta"><div class="ph-name">MC Tutoring Assistant</div>' +
      '<div class="ph-status"><span class="dot"></span> Online · Library &amp; Tutoring Center</div></div>' +
      '<button class="ph-reset" title="Restart">↺</button>' +
      "</div>" +
      '<div class="thread" id="chat-thread"></div>' +
      '<div class="composer" id="chat-composer"></div>' +
      "</div>";
    thread = $("#chat-thread", host);
    composer = $("#chat-composer", host);
    $(".ph-reset", host).addEventListener("click", start);
    start();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", mount);
  } else {
    mount();
  }
})();
