/* our store Agent Assist — Knowledge Base + sample tickets.
   The KB is the corpus the RAG retriever searches. Each chunk carries a doc
   title, category, tags (weighted for retrieval), and the verbatim policy text
   the model is allowed to ground answers in. */

window.KB = [
  {
    id: "returns-window",
    doc: "Returns Policy",
    category: "Returns & Refunds",
    tags: ["return", "returns", "restocking", "fee", "refund", "wrong size", "unused", "packaging", "return form", "eligible", "eligibility"],
    text: "Standard items are returnable within 1 year of purchase. Returns within 90 days: no restocking fee. Returns on days 91–365: 10% restocking fee. Items must be unused and in their original packaging with all parts included. A Return Form is required to start any return. Refunds are issued to the original payment method within 4–5 business days after the item is received and inspected."
  },
  {
    id: "returns-nonreturnable",
    doc: "Returns Policy",
    category: "Returns & Refunds",
    tags: ["return", "non-returnable", "cut", "custom", "clearance", "hazardous", "final sale"],
    text: "Non-returnable items include custom-cut or custom-fabricated products, clearance/final-sale items, and hazardous materials that cannot be shipped back safely. Special-order items may be subject to a restocking fee set by the manufacturer. If a customer is unsure whether an item qualifies, agents should check the product page 'Returnable' flag before confirming."
  },
  {
    id: "shipping-general",
    doc: "Shipping Policy",
    category: "Shipping & Delivery",
    tags: ["shipping", "delivery", "free shipping", "ship", "cutoff", "same day", "transit", "arrive", "when"],
    text: "Orders over $99 ship free within the contiguous US. In-stock orders placed before 3:00 PM ET ship the same business day. Standard ground transit is 2–5 business days depending on destination. Expedited (2-day and overnight) options are available at checkout. Tracking numbers are emailed automatically once a label is created."
  },
  {
    id: "order-status",
    doc: "Order Status Guide",
    category: "Orders",
    tags: ["order", "status", "tracking", "where", "shipped", "processing", "backorder", "delayed", "eta"],
    text: "Order statuses are: Processing (payment cleared, warehouse picking), Shipped (label created, tracking active), Partially Shipped (multi-warehouse order split into shipments), Backordered (item awaiting restock — customer is emailed an ETA), and Delivered. Agents can look up any order in NetSuite by order number or customer email. For backorders, provide the restock ETA shown on the order record; never promise a date that is not on the record."
  },
  {
    id: "warranty-general",
    doc: "Warranty Policy",
    category: "Warranty",
    tags: ["warranty", "defect", "defective", "manufacturer", "replacement", "claim", "broken", "failed"],
    text: "Most products carry the manufacturer's warranty, which varies by brand (commonly 1–5 years). our store facilitates warranty claims but the manufacturer makes the final determination on defect coverage. For a defective item within 30 days of delivery, our store will send a free advance replacement. Beyond 30 days, the customer submits a warranty claim and our store coordinates with the manufacturer. Physical damage and improper installation are not covered."
  },
  {
    id: "trademaster-program",
    doc: "TradeMaster Program",
    category: "Accounts & Programs",
    tags: ["trademaster", "trade master", "loyalty", "pro", "discount", "net terms", "membership", "rewards", "points"],
    text: "TradeMaster is our store's free loyalty program for trade professionals. Members earn points on every order (redeemable for account credit), get access to member-only pricing on select brands, and qualify for Net-30 terms after account approval. Enrollment is free; agents can invite a customer to enroll by sending the TradeMaster sign-up link. Points post after an order is delivered and do not expire while the account stays active."
  },
  {
    id: "compat-watts-valve",
    doc: "Product Spec — Watts Pressure Reducing Valves",
    category: "Product Specs",
    tags: ["watts", "pressure reducing valve", "prv", "valve", "compatibility", "size", "3/4", "1/2", "thread", "npt"],
    text: "Watts LFN45B series pressure reducing valves are available in 1/2\", 3/4\", and 1\" sizes with female NPT threaded connections. The 3/4\" LFN45B has a factory preset of 50 psi, adjustable 25–75 psi. It is lead-free and approved for potable water. Confirm the customer's existing line size before recommending a replacement; a 3/4\" valve does not fit 1/2\" or 1\" lines without an adapter/union."
  },
  {
    id: "compat-navien-parts",
    doc: "Product Spec — Navien Combi Boiler Accessories",
    category: "Product Specs",
    tags: ["navien", "combi", "boiler accessory", "isolation valve", "service kit", "npe", "nfc"],
    text: "our store stocks Navien-approved service accessories: isolation/service valve kits, condensate neutralizers, and vent adapters for NPE and NFC series combi boilers. These are installation accessories only. our store does not provide boiler diagnostic, error-code troubleshooting, or repair guidance — those require a licensed technician and are outside customer-service scope."
  },
  {
    id: "brand-voice",
    doc: "Brand Voice Guide",
    category: "Internal",
    tags: ["voice", "tone", "brand", "greeting", "sign off", "real people real service"],
    text: "Our brand voice is warm, plain-spoken, and genuinely helpful and human. Lead with the answer, avoid jargon, and never sound scripted. Acknowledge the customer's situation in one line, give the concrete answer with any steps, and close with a clear next action. Never over-promise on dates, credits, or coverage that isn't confirmed."
  }
];

/* Safety-critical categories are hard-coded to escalate — never answered by AI.
   Matched against the customer message to pre-flag the ticket for the agent. */
window.SAFETY_TERMS = [
  "boiler diagnos", "error code", "e003", "gas line", "gas leak", "smell gas",
  "wiring", "electrical", "wire it", "refrigerant", "furnace not", "furnace won",
  "ignit", "flame sensor", "combustion", "carbon monoxide", "how do i install",
  "how to install", "hook up the gas", "diagnose", "troubleshoot my"
];

/* High-tension / emotional escalations route to a human manager. */
window.TENSION_TERMS = [
  "lawyer", "sue", "attorney", "furious", "ridiculous", "worst", "scam",
  "never ordering", "cancel my account", "unacceptable", "manager now", "report you"
];

/* Sample tickets. `channel`, `customer`, and a small thread history.
   The first customer message is what the assist engine reads. */
window.TICKETS = [
  {
    id: "T-4471",
    customer: "Dana Whitfield",
    company: "Whitfield Plumbing LLC",
    channel: "chat",
    subject: "Return — wrong size pressure reducing valve",
    status: "open",
    priority: "normal",
    time: "2m ago",
    kind: "answerable",
    thread: [
      { from: "customer", time: "9:41 AM", text: "Hi, I ordered a Watts 3/4\" pressure reducing valve about 6 weeks ago and I need to return it — I bought the wrong size. Is there a fee and how do I start?" }
    ]
  },
  {
    id: "T-4472",
    customer: "Marcus Reyes",
    company: "Reyes Heating & Air",
    channel: "phone",
    subject: "Navien combi boiler error code E003",
    status: "open",
    priority: "high",
    time: "5m ago",
    kind: "safety",
    thread: [
      { from: "customer", time: "9:38 AM", text: "My Navien combi boiler keeps throwing an error code E003 — can you help me figure out what's wrong and fix it?" }
    ]
  },
  {
    id: "T-4473",
    customer: "Priya Anand",
    company: "—",
    channel: "email",
    subject: "Where is my order? Placed Tuesday",
    status: "open",
    priority: "normal",
    time: "14m ago",
    kind: "answerable",
    thread: [
      { from: "customer", time: "9:29 AM", text: "I placed order #SH-88213 on Tuesday and it still says Processing. When will it ship? I need it this week." }
    ]
  },
  {
    id: "T-4474",
    customer: "Leo Fontaine",
    company: "Fontaine Mechanical",
    channel: "chat",
    subject: "Free shipping threshold + TradeMaster",
    status: "open",
    priority: "low",
    time: "22m ago",
    kind: "answerable",
    thread: [
      { from: "customer", time: "9:21 AM", text: "Do I get free shipping if my cart is $80? And is it worth signing up for TradeMaster — what do I actually get?" }
    ]
  },
  {
    id: "T-4475",
    customer: "Sandra Okoro",
    company: "—",
    channel: "email",
    subject: "Defective circulator pump — third one!",
    status: "open",
    priority: "high",
    time: "31m ago",
    kind: "tension",
    thread: [
      { from: "customer", time: "9:12 AM", text: "This is the THIRD circulator pump that arrived dead. This is completely unacceptable and honestly a scam. I want a manager now or I'm reporting you." }
    ]
  },
  {
    id: "T-4476",
    customer: "Tom Bradley",
    company: "Bradley & Sons",
    channel: "chat",
    subject: "Will a 3/4\" valve fit my 1/2\" line?",
    status: "open",
    priority: "normal",
    time: "40m ago",
    kind: "answerable",
    thread: [
      { from: "customer", time: "9:03 AM", text: "Quick one — I have a 1/2\" water line. Will the Watts 3/4\" LFN45B pressure reducing valve fit it directly?" }
    ]
  }
];


/* Demo-mode fallbacks — used when the live AI helper isn't available
   (e.g. self-hosted on GitHub Pages). Lets the whole flow run with realistic,
   pre-written responses so the showcase works with no API key. */
window.DEMO = {
  "T-4471": {
    draft: "Good news — since your order was about 6 weeks ago, you're inside the 90-day window, so there's no restocking fee. To get started, just submit a Return Form and make sure the valve is unused and in its original packaging with all parts included. Once we receive and inspect it, your refund goes back to your original payment method within 4\u20135 business days. [Source: Returns Policy]",
    replies: [{ sentiment: "positive", text: "Perfect \u2014 thank you so much for the clear steps and the no-fee return. I'll get the Return Form in today!" }]
  },
  "T-4473": {
    draft: "Thanks for your patience! In-stock orders placed before 3 PM ET ship the same business day, and you'll get a tracking email automatically once the label is created. Order #SH-88213 is still in Processing, which means our warehouse is picking it \u2014 I'll make sure it's moving so it reaches you this week and send your tracking the moment it ships. [Source: Order Status Guide]",
    replies: [{ sentiment: "positive", text: "Great, thank you for checking on it \u2014 I really appreciate the quick help!" }]
  },
  "T-4474": {
    draft: "Happy to help! Free shipping kicks in on orders over $99, so an $80 cart is just short \u2014 adding a little more would get you there. And yes, TradeMaster is worth it: it's free to join, you earn points on every order, unlock member-only pricing on select brands, and can qualify for Net-30 terms after approval. Want me to send the sign-up link? [Source: TradeMaster Program]",
    replies: [{ sentiment: "positive", text: "Nice \u2014 I'll bump my order over $99 and sign up for TradeMaster. Thanks!" }]
  },
  "T-4476": {
    draft: "Thanks for checking first! The Watts 3/4\" LFN45B has 3/4\" connections, so it won't thread directly onto a 1/2\" line without an adapter or union. The LFN45B also comes in a 1/2\" size that would fit your line directly \u2014 that's the one I'd recommend. [Source: Product Spec \u2014 Watts Pressure Reducing Valves]",
    replies: [{ sentiment: "negative", text: "Wait, so the 3/4\" I already bought won't work at all? Why can't I just return it and swap for the 1/2\" version?" }]
  }
};

/* Customer-facing FAQ — self-serve answers, grounded in the KB above. */
window.FAQS = [
  { q: "How long do I have to return an item?", doc: "Returns Policy", a: "Standard items are returnable within 1 year of purchase. Returns within 90 days have no restocking fee; days 91–365 carry a 10% restocking fee. Items must be unused and in their original packaging, and a Return Form is required." },
  { q: "Is there a restocking fee?", doc: "Returns Policy", a: "No fee on returns within 90 days. A 10% restocking fee applies on days 91–365. Custom-cut, clearance, and hazardous items are non-returnable." },
  { q: "Do I get free shipping?", doc: "Shipping Policy", a: "Orders over $99 ship free within the contiguous US. In-stock orders placed before 3:00 PM ET ship the same business day; standard ground transit is 2–5 business days." },
  { q: "How do I check my order status?", doc: "Order Status Guide", a: "You'll get a tracking email once your label is created. Statuses are Processing, Shipped, Partially Shipped, Backordered (with an ETA), and Delivered." },
  { q: "What does the warranty cover?", doc: "Warranty Policy", a: "Most products carry the manufacturer's warranty (commonly 1–5 years). Defective items within 30 days of delivery get a free advance replacement; beyond 30 days we coordinate a claim with the manufacturer. Physical damage and improper installation aren't covered." },
  { q: "What is TradeMaster and is it worth it?", doc: "TradeMaster Program", a: "TradeMaster is our free loyalty program for trade pros: earn points on every order, unlock member-only pricing on select brands, and qualify for Net-30 terms after approval." },
  { q: "Can you help with a boiler error code or gas line?", doc: "Product Specs", a: "Safety-critical diagnostics — boiler error codes, gas lines, electrical wiring, refrigerant — require a licensed technician. Our team connects you with technical support rather than guessing." }
];
