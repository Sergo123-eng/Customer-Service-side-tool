/* Agent Assist — main app. */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "assistLayout": "rail",
  "accent": "#2f6bd8",
  "showScores": true,
  "density": "regular"
}/*EDITMODE-END*/;

const AGENT_NAME = "Sergo Beridze";
const AGENT_SHORT = "Sergo B.";

const ACTION_META = {
  accepted: { label: "Accepted as-is", tone: "good" },
  edited: { label: "Edited & sent", tone: "warn" },
  polished: { label: "AI-polished", tone: "warn" },
  escalated: { label: "Escalated", tone: "esc" },
  rejected: { label: "Dismissed", tone: "bad" },
  manual: { label: "Manual reply", tone: "neutral" }
};

function lastCustomerTurn(t) {
  const c = t.thread.filter(x => x.from === "customer");
  return c.length ? c[c.length - 1] : null;
}
function customerMsg(t) {
  const m = lastCustomerTurn(t);
  return m ? m.text : "";
}
function nowTime() {
  return new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}

// Customer role-play prompt — drives the auto-reply with sentiment.
const CUSTOMER_SIM_PROMPT = `You role-play the CUSTOMER in a support chat. Read the conversation and react to the AGENT'S most recent reply, from the customer's point of view.

First judge sentiment:
- "positive": the agent gave good news or resolved the issue (e.g. no fee, it's covered, here's how).
- "negative": the agent gave bad news — a fee, a denial, or told them something can't be done (e.g. an item can't be returned, out of scope, must wait).

Then write the customer's next message:
- If positive: a short, warm thank-you (1 sentence). They're satisfied and wrapping up.
- If negative: a short, slightly frustrated follow-up QUESTION that pushes for a reason or a way around it (e.g. "But why can't the valve be returned?"). 1–2 sentences.

Sound like a real person, reference the specific product/issue. Output ONLY JSON: {"sentiment":"positive"|"negative","reply":"..."}`;

function parseReply(raw) {
  if (!raw) return null;
  let s = raw.trim().replace(/^```json/i, "").replace(/^```/, "").replace(/```$/, "").trim();
  const a = s.indexOf("{"), b = s.lastIndexOf("}");
  if (a >= 0 && b > a) { try { return JSON.parse(s.slice(a, b + 1)); } catch (e) {} }
  return null;
}

const HAS_AI = !!(typeof window !== "undefined" && window.claude && window.claude.complete);

// Local, offline "polish" for demo mode: tidy capitalization + spacing.
function localTidy(text) {
  let s = text.replace(/\s+/g, " ").trim();
  s = s.replace(/(^|[.!?]\s+)([a-z])/g, (m, p, c) => p + c.toUpperCase());
  s = s.charAt(0).toUpperCase() + s.slice(1);
  if (!/[.!?]$/.test(s)) s += ".";
  return s;
}

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);
  const [tickets, setTickets] = useState(() => window.TICKETS.map(x => ({ ...x, thread: [...x.thread] })));
  const [activeId, setActiveId] = useState(tickets[0].id);
  const [assist, setAssist] = useState({});
  const [composer, setComposer] = useState({});
  const [draftSnap, setDraftSnap] = useState({});
  const [log, setLog] = useState([]);
  const [qaOpen, setQaOpen] = useState(false);
  const [typing, setTyping] = useState({});
  const [custCount, setCustCount] = useState({});
  const composerRef = useRef(null);

  const active = tickets.find(x => x.id === activeId);
  const aState = assist[activeId];
  const closed = active.status === "closed";
  const lastCust = active ? customerMsg(active) : "";

  useEffect(() => {
    document.documentElement.style.setProperty("--accent", t.accent);
  }, [t.accent]);

  // Re-runs whenever the active ticket OR its latest customer message changes.
  useEffect(() => {
    if (active && !closed) ensureAssist(active, false);
    // eslint-disable-next-line
  }, [activeId, lastCust]);

  async function ensureAssist(tk, force) {
    const turn = lastCustomerTurn(tk);
    const message = turn ? turn.text : "";
    const cur = assist[tk.id];
    if (!force && cur && cur.forMsg === message) return;
    // A positive thank-you doesn't need a draft — the ticket is basically done.
    if (turn && turn.sentiment === "positive") {
      setAssist(a => ({ ...a, [tk.id]: { status: "satisfied", forMsg: message } }));
      return;
    }
    const { hits, confidence } = window.Assist.retrieve(message);
    const cls = window.Assist.classify(message);
    setAssist(a => ({ ...a, [tk.id]: { status: "drafting", hits, confidence, cls, forMsg: message } }));
    const res = await window.Assist.draft({ message, hits, safety: cls.safety, tension: cls.tension, demo: (window.DEMO || {})[tk.id] });
    setAssist(a => ({
      ...a,
      [tk.id]: {
        status: res.error ? "error" : "ready", forMsg: message,
        hits, confidence, cls,
        draft: res.text, escalated: res.escalated, error: res.error
      }
    }));
  }

  // After the agent sends, the customer replies back (once or twice), with sentiment.
  async function maybeCustomerReply(ticketId, agentText, action) {
    if (action === "escalated") return;
    const tk = tickets.find(x => x.id === ticketId);
    if (!tk || tk.status === "closed") return;
    if ((custCount[ticketId] || 0) >= 2) return;
    const transcript = [...tk.thread, { from: "agent", text: agentText }]
      .map(m => (m.from === "agent" ? "Agent" : "Customer") + ": " + m.text).join("\n");
    setTyping(tp => ({ ...tp, [ticketId]: true }));
    // Demo mode (no live AI): use a pre-written customer reply.
    if (!HAS_AI) {
      const demo = (window.DEMO || {})[ticketId];
      const reply = demo && demo.replies && demo.replies[custCount[ticketId] || 0];
      setTimeout(() => {
        if (reply) {
          setTickets(ts => ts.map(x => x.id === ticketId
            ? { ...x, thread: [...x.thread, { from: "customer", time: nowTime(), text: reply.text, sentiment: reply.sentiment }] }
            : x));
          setCustCount(c => ({ ...c, [ticketId]: (c[ticketId] || 0) + 1 }));
        }
        setTyping(tp => ({ ...tp, [ticketId]: false }));
      }, 1300);
      return;
    }
    try {
      const raw = await window.claude.complete({
        system: CUSTOMER_SIM_PROMPT,
        max_tokens: 220,
        messages: [{ role: "user", content: "Conversation so far:\n" + transcript + "\n\nWrite the customer's next reply as JSON." }]
      });
      const parsed = parseReply(raw);
      if (parsed && parsed.reply) {
        const sentiment = parsed.sentiment === "positive" ? "positive" : "negative";
        setTickets(ts => ts.map(x => x.id === ticketId
          ? { ...x, thread: [...x.thread, { from: "customer", time: nowTime(), text: parsed.reply, sentiment }] }
          : x));
        setCustCount(c => ({ ...c, [ticketId]: (c[ticketId] || 0) + 1 }));
      }
    } catch (e) { /* silent — no auto-reply on failure */ }
    setTyping(tp => ({ ...tp, [ticketId]: false }));
  }

  function setComposerText(text, snapshot) {
    setComposer(c => ({ ...c, [activeId]: text }));
    if (snapshot !== undefined) setDraftSnap(d => ({ ...d, [activeId]: snapshot }));
  }

  function useDraft() {
    if (!aState || !aState.draft) return;
    setComposerText(aState.draft, aState.draft);
    setTimeout(() => composerRef.current && composerRef.current.focus(), 30);
  }

  function insertFaq(faq) {
    const existing = composer[activeId] || "";
    const block = faq.a + " [Source: " + faq.doc + "]";
    setComposerText(existing ? existing.trim() + "\n\n" + block : block, undefined);
    setTimeout(() => composerRef.current && composerRef.current.focus(), 30);
  }

  function logEntry(action, preview) {
    setLog(l => [{
      id: Math.random().toString(36).slice(2),
      ticketId: active.id, customer: active.customer,
      action, preview, time: nowTime()
    }, ...l]);
  }

  // Send a reply — the ticket STAYS OPEN so the conversation can continue.
  function send(forceAction) {
    const text = (composer[activeId] || "").trim();
    if (!text) return;
    let action = forceAction;
    if (!action) {
      const snap = draftSnap[activeId];
      if (snap && text === snap) action = "accepted";
      else if (snap && text !== snap) action = "edited";
      else action = "manual";
    }
    setTickets(ts => ts.map(x => x.id === activeId
      ? { ...x, thread: [...x.thread, { from: "agent", time: nowTime(), text, action }] }
      : x));
    logEntry(action, text);
    setComposer(c => ({ ...c, [activeId]: "" }));
    setDraftSnap(d => ({ ...d, [activeId]: undefined }));
    const sendId = activeId;
    setTimeout(() => maybeCustomerReply(sendId, text, action), 700);
  }

  function escalate() {
    if (!aState || !aState.escalated) return;
    setComposerText(aState.draft, aState.draft);
    setTimeout(() => send("escalated"), 0);
  }

  function dismiss() {
    logEntry("rejected", aState && aState.draft ? aState.draft : "(no draft)");
    setAssist(a => ({ ...a, [activeId]: { ...a[activeId], status: "dismissed" } }));
  }

  function setStatus(status) {
    setTickets(ts => ts.map(x => x.id === activeId ? { ...x, status } : x));
    if (status === "open" && !assist[activeId]) ensureAssist(active, true);
  }

  // AI that aligns to the agent's OWN typed text — polish/expand, grounded.
  async function polish(text) {
    if (!text.trim()) return null;
    if (!HAS_AI) { const out = localTidy(text); logEntry("polished", out); return out; }
    const message = customerMsg(active);
    const hits = (aState && aState.hits) || window.Assist.retrieve(message).hits;
    const context = hits.length ? hits.map(h => `[${h.doc}] ${h.text}`).join("\n\n") : "(no retrieved policy context)";
    try {
      const out = await window.claude.complete({
        system: "You help a customer-service agent polish THEIR OWN reply. Rewrite the agent's rough notes into a clear, warm, plain-spoken, customer-ready message. Preserve the agent's intent and every specific they included. Only use facts consistent with the retrieved context — never invent policy, prices, dates, or terms. Keep it to one short paragraph. If a policy is referenced, end with the source document name in brackets. Output ONLY the rewritten reply, nothing else.",
        max_tokens: 400,
        messages: [{ role: "user", content: `<retrieved_context>\n${context}\n</retrieved_context>\n\nThe customer wrote:\n"${message}"\n\nThe agent's rough reply:\n"${text}"\n\nRewrite the agent's reply.` }]
      });
      const cleaned = (out || "").trim();
      if (cleaned) logEntry("polished", cleaned);
      return cleaned || null;
    } catch (e) { return null; }
  }

  return (
    <div className="app" data-density={t.density}>
      <TopBar
        tickets={tickets} activeId={activeId} onSelect={setActiveId}
        logCount={log.length} onLog={() => setQaOpen(true)}
      />

      <div className="workspace" data-layout={t.assistLayout}>
        <FaqPanel onInsert={insertFaq} disabled={closed} />

        <section className="convo">
          <Conversation ticket={active} closed={closed} typing={!!typing[activeId]}
            onClose={() => setStatus("closed")} onReopen={() => setStatus("open")} />
          <Composer
            ref={composerRef}
            value={composer[activeId] || ""}
            onChange={v => setComposerText(v, undefined)}
            onSend={() => send()}
            onPolish={polish}
            closed={closed}
            fromDraft={!!draftSnap[activeId] && composer[activeId] === draftSnap[activeId]}
          />
        </section>

        <AssistPanel
          layout={t.assistLayout}
          showScores={t.showScores}
          state={aState}
          closed={closed}
          onUse={useDraft}
          onRegen={() => ensureAssist(active, true)}
          onDismiss={dismiss}
          onEscalate={escalate}
        />
      </div>

      {qaOpen && <QALog log={log} onClose={() => setQaOpen(false)} />}

      <TweaksPanel>
        <TweakSection label="Assist layout" />
        <TweakRadio label="Panel" value={t.assistLayout}
          options={["rail", "focus", "drawer"]}
          onChange={v => setTweak("assistLayout", v)} />
        <TweakToggle label="Show match scores" value={t.showScores}
          onChange={v => setTweak("showScores", v)} />
        <TweakSection label="Appearance" />
        <TweakColor label="Accent" value={t.accent}
          options={["#2f6bd8", "#0e7a5f", "#b0432f", "#5a44c9", "#1a1a1a"]}
          onChange={v => setTweak("accent", v)} />
        <TweakRadio label="Density" value={t.density}
          options={["compact", "regular"]}
          onChange={v => setTweak("density", v)} />
      </TweaksPanel>
    </div>
  );
}

/* ---------- Top bar with conversation switcher ---------- */
function TopBar({ tickets, activeId, onSelect, logCount, onLog }) {
  const [open, setOpen] = useState(false);
  const active = tickets.find(x => x.id === activeId);
  return (
    <header className="topbar">
      <div className="brand">
        <span className="brand-mark"><Spark size={16} color="#fff" /></span>
        <div className="brand-txt">
          <strong>Agent Assist</strong>
          <span>AI copilot for support</span>
        </div>
        {!HAS_AI && <span className="demo-pill" title="Live AI helper not detected — showing pre-written sample responses.">Demo mode</span>}
      </div>

      <div className="switcher-wrap">
        <button className="switcher" onClick={() => setOpen(o => !o)}>
          <Avatar name={active.customer} size={26} />
          <span className="switcher-txt">
            <em>{active.customer}</em>
            <small>{active.subject}</small>
          </span>
          <span className="switcher-caret">▾</span>
        </button>
        {open && (
          <>
            <div className="switcher-backdrop" onClick={() => setOpen(false)} />
            <div className="switcher-menu">
              <div className="switcher-menu-head">Conversations <span>{tickets.length}</span></div>
              {tickets.map(tk => (
                <button key={tk.id}
                  className={"switcher-item" + (tk.id === activeId ? " on" : "")}
                  onClick={() => { onSelect(tk.id); setOpen(false); }}>
                  <Avatar name={tk.customer} size={30} />
                  <span className="si-body">
                    <span className="si-top">
                      <span className="si-name">{tk.customer}</span>
                      <span className="si-time">{tk.time}</span>
                    </span>
                    <span className="si-subj">{tk.subject}</span>
                    <span className="si-meta">
                      <ChannelTag channel={tk.channel} />
                      {tk.priority === "high" && <Pill tone="bad">High</Pill>}
                      {tk.status === "closed" && <Pill tone="good">Closed</Pill>}
                    </span>
                  </span>
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      <div className="topbar-right">
        <button className="btn ghost" onClick={onLog}>
          QA log {logCount > 0 && <span className="log-count">{logCount}</span>}
        </button>
        <div className="me">
          <Avatar name={AGENT_NAME} size={30} />
          <span className="me-name">{AGENT_SHORT}<em>CS Agent</em></span>
        </div>
      </div>
    </header>
  );
}

/* ---------- Customer FAQ panel (replaces the inbox) ---------- */
function FaqPanel({ onInsert, disabled }) {
  const [open, setOpen] = useState(0);
  return (
    <aside className="faq">
      <div className="faq-head">
        <div>
          <strong>Help Center</strong>
          <span>What customers can self-serve</span>
        </div>
      </div>
      <div className="faq-list">
        {window.FAQS.map((f, i) => {
          const isOpen = open === i;
          return (
            <div key={i} className={"faq-item" + (isOpen ? " open" : "")}>
              <button className="faq-q" onClick={() => setOpen(isOpen ? -1 : i)}>
                <span>{f.q}</span>
                <span className="faq-caret">{isOpen ? "–" : "+"}</span>
              </button>
              {isOpen && (
                <div className="faq-a">
                  <p>{f.a}</p>
                  <div className="faq-a-foot">
                    <span className="faq-src">{f.doc}</span>
                    <button className="faq-insert" disabled={disabled} onClick={() => onInsert(f)}>
                      Insert into reply
                    </button>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </aside>
  );
}

/* ---------- Conversation ---------- */
function SentimentTag({ s }) {
  if (!s) return null;
  const good = s === "positive";
  return <span className={"senti " + (good ? "pos" : "neg")}>{good ? "Satisfied" : "Needs follow-up"}</span>;
}

function Conversation({ ticket, closed, typing, onClose, onReopen }) {
  const scrollRef = useRef(null);
  useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
  }, [ticket.id, ticket.thread.length, typing]);
  return (
    <>
      <div className="convo-head">
        <div className="convo-head-l">
          <Avatar name={ticket.customer} size={38} />
          <div>
            <div className="convo-name">{ticket.customer}</div>
            <div className="convo-sub">{ticket.company !== "—" ? ticket.company + " · " : ""}{ticket.id}</div>
          </div>
        </div>
        <div className="convo-head-r">
          <ChannelTag channel={ticket.channel} />
          {closed
            ? <button className="btn ghost sm" onClick={onReopen}>Reopen</button>
            : <button className="btn ghost sm danger" onClick={onClose}>Close ticket</button>}
        </div>
      </div>
      <div className="thread" ref={scrollRef}>
        {ticket.thread.map((m, i) => (
          <div key={i} className={"msg msg-" + m.from}>
            {m.from === "customer" && <Avatar name={ticket.customer} size={30} />}
            <div className="bubble">
              <div className="bubble-meta">
                {m.from === "customer" ? ticket.customer.split(" ")[0] : "You"} · {m.time}
                {m.from === "customer" && <SentimentTag s={m.sentiment} />}
              </div>
              <div className="bubble-text">{m.text}</div>
            </div>
          </div>
        ))}
        {typing && (
          <div className="msg msg-customer">
            <Avatar name={ticket.customer} size={30} />
            <div className="bubble typing"><span /><span /><span /></div>
          </div>
        )}
        {closed && <div className="thread-closed">Ticket closed by {AGENT_SHORT} · reopen to keep the conversation going</div>}
      </div>
    </>
  );
}

/* ---------- Composer with AI polish ---------- */
const Composer = React.forwardRef(function Composer({ value, onChange, onSend, onPolish, closed, fromDraft }, ref) {
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState(false);
  if (closed) {
    return (
      <div className="composer resolved">
        <span className="resolved-note">Ticket is closed. Reopen it to reply.</span>
      </div>
    );
  }
  async function doPolish() {
    if (busy || !value.trim()) return;
    setBusy(true); setErr(false);
    const out = await onPolish(value);
    setBusy(false);
    if (out) { onChange(out); setTimeout(() => ref && ref.current && ref.current.focus(), 20); }
    else setErr(true);
  }
  return (
    <div className="composer">
      {fromDraft && <div className="composer-flag"><Spark size={12} color="var(--accent)" /> AI draft inserted — edit before you send</div>}
      {err && <div className="composer-err">Couldn't reach the AI just now — try Polish again in a moment.</div>}
      <textarea
        ref={ref}
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder="Type your reply in your own words, then hit Polish to align it — or use the AI draft…"
        onKeyDown={e => { if ((e.metaKey || e.ctrlKey) && e.key === "Enter") onSend(); }}
      />
      <div className="composer-bar">
        <button className={"btn ai" + (busy ? " busy" : "")} onClick={doPolish} disabled={!value.trim() || busy}>
          {busy ? <><span className="spin" /> Aligning…</> : <><Spark size={13} color="var(--accent)" /> Polish &amp; align</>}
        </button>
        <div className="composer-bar-r">
          <span className="composer-hint">⌘↵ to send</span>
          <button className="btn primary" onClick={onSend} disabled={!value.trim()}>
            <SendGlyph /> Send reply
          </button>
        </div>
      </div>
    </div>
  );
});

/* ---------- Assist panel ---------- */
function AssistPanel({ layout, showScores, state, closed, onUse, onRegen, onDismiss, onEscalate }) {
  const [sourcesOpen, setSourcesOpen] = useState(true);
  return (
    <aside className="assist" data-layout={layout}>
      <div className="assist-head">
        <span className="assist-title"><Spark size={14} color="var(--accent)" /> Agent Assist</span>
        {state && (state.status === "ready" || state.status === "dismissed") && !state.escalated && !closed &&
          <button className="mini-btn" onClick={onRegen} title="Regenerate">↻</button>}
      </div>

      {closed ? (
        <div className="assist-empty">This ticket is closed. Reopen it to bring assist back.</div>
      ) : !state || state.status === "drafting" ? (
        <AssistLoading state={state} />
      ) : state.status === "satisfied" ? (
        <div className="assist-empty satisfied">Customer sounds satisfied — you can close the ticket.</div>
      ) : (
        <AssistReady
          state={state} layout={layout} showScores={showScores}
          sourcesOpen={sourcesOpen} setSourcesOpen={setSourcesOpen}
          onUse={onUse} onDismiss={onDismiss} onEscalate={onEscalate}
        />
      )}
    </aside>
  );
}

function AssistLoading({ state }) {
  const retrieved = state && state.hits;
  return (
    <div className="assist-scroll">
      <div className="assist-step">
        <span className="dot-pulse" /> {retrieved ? "Retrieved knowledge base" : "Searching knowledge base…"}
      </div>
      {retrieved && (
        <div className="src-list">
          {state.hits.map(h => <div key={h.id} className="src-card mini"><span className="src-doc">{h.doc}</span></div>)}
        </div>
      )}
      <div className="assist-step"><span className="dot-pulse" /> Drafting a policy-grounded reply…</div>
      <div className="skeleton"><span /><span /><span /></div>
    </div>
  );
}

function Sources({ hits, showScores }) {
  if (!hits || !hits.length) {
    return <div className="src-none">No matching KB document — low confidence. Verify manually or escalate.</div>;
  }
  const max = hits[0].score || 1;
  return (
    <div className="src-list">
      {hits.map(h => (
        <div key={h.id} className="src-card">
          <div className="src-top">
            <span className="src-doc">{h.doc}</span>
            {showScores && <span className="src-score">{Math.round((h.score / max) * 100)}%</span>}
          </div>
          <div className="src-cat">{h.category}</div>
          <p className="src-text">{h.text}</p>
          {h.matched && h.matched.length > 0 &&
            <div className="src-chips">{h.matched.map(m => <span key={m} className="chip">{m}</span>)}</div>}
        </div>
      ))}
    </div>
  );
}

function AssistReady({ state, layout, showScores, sourcesOpen, setSourcesOpen, onUse, onDismiss, onEscalate }) {
  const escBanner = state.escalated && (
    <div className={"esc-banner " + state.escalated}>
      <div className="esc-title">
        {state.escalated === "safety" ? "⚠ Safety-critical — do not answer with AI" : "⚠ High-tension — route to a human"}
      </div>
      <div className="esc-sub">
        {state.escalated === "safety"
          ? "Mechanical/gas/electrical diagnosis is hard-blocked in the system prompt. Transfer to technical support."
          : "Emotional or commercial dispute detected. Bring in a CS manager rather than an automated reply."}
      </div>
    </div>
  );

  const sourcesBlock = (
    <div className="assist-block">
      <button className="block-head" onClick={() => setSourcesOpen(o => !o)}>
        <span>Retrieved sources ({state.hits ? state.hits.length : 0})</span>
        <span className="caret">{sourcesOpen ? "▾" : "▸"}</span>
      </button>
      {sourcesOpen && <Sources hits={state.hits} showScores={showScores} />}
    </div>
  );

  const draftBlock = (
    <div className="assist-block">
      <div className="draft-head">
        <span>Suggested draft</span>
        {!state.escalated && <ConfidenceMeter level={state.confidence} />}
      </div>
      {state.status === "error" ? (
        <div className="draft-error">{state.error}</div>
      ) : state.status === "dismissed" ? (
        <div className="draft-dismissed">Draft dismissed. Reply manually or regenerate.</div>
      ) : (
        <div className={"draft-card" + (state.escalated ? " esc" : "")}>{state.draft}</div>
      )}
    </div>
  );

  const actions = state.status === "dismissed" ? null : (
    <div className="assist-actions">
      {state.escalated ? (
        <button className="btn primary block" onClick={onEscalate}>
          <SendGlyph /> {state.escalated === "safety" ? "Transfer to tech support" : "Escalate to manager"}
        </button>
      ) : (
        <>
          <button className="btn primary block" onClick={onUse}><Spark size={13} color="#fff" /> Use draft in reply</button>
          <button className="btn ghost block" onClick={onDismiss}>Dismiss</button>
        </>
      )}
    </div>
  );

  return (
    <div className="assist-scroll">
      {escBanner}
      {layout === "focus" ? <>{draftBlock}{actions}{sourcesBlock}</> : <>{sourcesBlock}{draftBlock}{actions}</>}
    </div>
  );
}

/* ---------- QA log slide-over ---------- */
function QALog({ log, onClose }) {
  return (
    <div className="overlay" onClick={onClose}>
      <div className="qa" onClick={e => e.stopPropagation()}>
        <div className="qa-head">
          <div>
            <strong>QA log</strong>
            <span>Every AI suggestion + agent decision, logged for review</span>
          </div>
          <button className="mini-btn" onClick={onClose}>✕</button>
        </div>
        {log.length === 0 ? (
          <div className="qa-empty">No decisions logged yet. Use, polish, dismiss, or escalate a draft and it appears here.</div>
        ) : (
          <div className="qa-list">
            {log.map(e => {
              const m = ACTION_META[e.action] || ACTION_META.manual;
              return (
                <div key={e.id} className="qa-row">
                  <div className="qa-row-top">
                    <Pill tone={m.tone}>{m.label}</Pill>
                    <span className="qa-cust">{e.customer}</span>
                    <span className="qa-time">{e.time}</span>
                  </div>
                  <div className="qa-preview">{e.preview}</div>
                </div>
              );
            })}
          </div>
        )}
        {log.length > 0 && (
          <div className="qa-foot">
            <span>{log.filter(e => e.action === "accepted" || e.action === "edited" || e.action === "polished").length} sent · {log.filter(e => e.action === "rejected").length} dismissed · {log.filter(e => e.action === "escalated").length} escalated</span>
          </div>
        )}
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
