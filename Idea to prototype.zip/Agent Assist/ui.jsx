/* Small presentational helpers for Agent Assist. Exported to window at the end. */
const { useState, useEffect, useRef } = React;

/* Simple assist mark — a rotated square "spark". Kept intentionally geometric. */
function Spark({ size = 14, color = "currentColor" }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" style={{ display: "block" }}>
      <path d="M12 2 L14.2 9.8 L22 12 L14.2 14.2 L12 22 L9.8 14.2 L2 12 L9.8 9.8 Z" fill={color} />
    </svg>
  );
}

function SendGlyph({ size = 15 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" aria-hidden="true" style={{ display: "block" }}>
      <path d="M3 11 L21 3 L14 21 L11 13 Z" fill="none" stroke="currentColor" strokeWidth="2" strokeLinejoin="round" />
    </svg>
  );
}

const CHANNEL_META = {
  chat: { label: "CHAT", color: "var(--accent)" },
  phone: { label: "PHONE", color: "#8a6d3b" },
  email: { label: "EMAIL", color: "#5a6b8a" }
};

function ChannelTag({ channel }) {
  const m = CHANNEL_META[channel] || CHANNEL_META.chat;
  return (
    <span className="chan-tag" style={{ color: m.color }}>
      <span className="chan-dot" style={{ background: m.color }} />
      {m.label}
    </span>
  );
}

function Avatar({ name, size = 34 }) {
  const initials = name.split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase();
  // stable hue from name
  let h = 0;
  for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) % 360;
  return (
    <span className="avatar" style={{
      width: size, height: size, fontSize: size * 0.38,
      background: `oklch(0.92 0.03 ${h})`, color: `oklch(0.42 0.09 ${h})`
    }}>{initials}</span>
  );
}

function Pill({ children, tone = "neutral" }) {
  return <span className={`pill pill-${tone}`}>{children}</span>;
}

function ConfidenceMeter({ level }) {
  const map = { high: 3, medium: 2, low: 1 };
  const n = map[level] || 1;
  const tone = level === "high" ? "good" : level === "medium" ? "warn" : "bad";
  return (
    <span className={`conf conf-${tone}`} title={`Retrieval confidence: ${level}`}>
      <span className="conf-bars">
        {[1, 2, 3].map(i => <span key={i} className={"conf-bar" + (i <= n ? " on" : "")} />)}
      </span>
      {level} confidence
    </span>
  );
}

Object.assign(window, { Spark, SendGlyph, ChannelTag, Avatar, Pill, ConfidenceMeter, CHANNEL_META });
