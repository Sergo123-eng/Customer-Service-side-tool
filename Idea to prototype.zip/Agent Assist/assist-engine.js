/* the store Agent Assist — retrieval + AI drafting engine.
   Exposes window.Assist with:
     retrieve(message)  -> { hits:[{...chunk, score, matched}], confidence, topScore }
     classify(message)  -> { safety, tension } booleans
     draft({message, hits, safety, tension}) -> async -> { text, escalated }
   Retrieval is a transparent keyword/tag overlap scorer (a stand-in for a vector
   store) so the UI can show WHY each doc was pulled. Drafting is a live Claude call
   grounded ONLY in retrieved context, per the assignment's system prompt. */

(function () {
  const STOP = new Set("a an the is are do does i my me we our you your it this that of to for on in at and or with about how what when where can could would should need my mine im i'm".split(" "));

  function tokenize(s) {
    return (s.toLowerCase().match(/[a-z0-9/"']+/g) || [])
      .map(t => t.replace(/^['"]+|['"]+$/g, ""))
      .filter(t => t && t.length > 1 && !STOP.has(t));
  }

  function retrieve(message) {
    const qTokens = tokenize(message);
    const qSet = new Set(qTokens);
    const hits = window.KB
      .filter(c => c.category !== "Internal")
      .map(c => {
        const hay = (c.text + " " + c.tags.join(" ") + " " + c.doc).toLowerCase();
        const matched = [];
        let score = 0;
        // tag hits weigh heaviest (curated retrieval signal)
        c.tags.forEach(tag => {
          if (message.toLowerCase().includes(tag)) { score += tag.includes(" ") ? 4 : 2; matched.push(tag); }
        });
        // token overlap on the body
        qSet.forEach(tok => {
          if (hay.includes(tok) && !matched.includes(tok)) { score += 1; matched.push(tok); }
        });
        return { ...c, score, matched: [...new Set(matched)].slice(0, 6) };
      })
      .filter(h => h.score > 0)
      .sort((a, b) => b.score - a.score);

    const top = hits.slice(0, 3);
    const topScore = top.length ? top[0].score : 0;
    // crude confidence: strong single match or two decent matches
    let confidence = "low";
    if (topScore >= 6) confidence = "high";
    else if (topScore >= 3) confidence = "medium";
    return { hits: top, confidence, topScore };
  }

  function classify(message) {
    const m = message.toLowerCase();
    const safety = window.SAFETY_TERMS.some(t => m.includes(t));
    const tension = window.TENSION_TERMS.some(t => m.includes(t));
    return { safety, tension };
  }

  const SYSTEM_PROMPT = `You are a customer-service Agent Assist AI. Your job is to help CS agents draft accurate, policy-grounded responses to customer inquiries.

RULES:
1. ONLY use facts from the <retrieved_context> provided. Never invent policy details, prices, warranty terms, or compatibility specs.
2. If retrieved context is insufficient, output exactly: "I don't have enough verified information for this — please check the knowledge base or escalate to a team lead."
3. For any mechanical diagnosis, gas lines, electrical wiring, or refrigerant questions: output a transfer message immediately and do not attempt an answer.
4. Draft in plain English, in a warm, plain-spoken, genuinely-helpful brand voice. Lead with the answer. One short paragraph max.
5. End every draft with the source document name in brackets, e.g. [Source: Returns Policy].
6. Do the arithmetic when a customer gives a timeframe (e.g. compute whether a return falls inside the 90-day window).

Output ONLY the drafted reply text — no preamble, no explanation.`;

  async function draft({ message, hits, safety, tension, demo }) {
    if (safety) {
      return {
        escalated: "safety",
        text: "I don't have verified troubleshooting information for that in our knowledge base, and this type of question requires a qualified technician. I'm transferring you to one of our technical support representatives right now who can help — please hold for a moment."
      };
    }
    if (tension) {
      return {
        escalated: "tension",
        text: "I'm really sorry — that's not the experience we want you to have, and I completely understand the frustration. I'm bringing a customer service manager into this conversation right now so we can make it right. They'll be with you in just a moment."
      };
    }

    const AI = window.claude && window.claude.complete;
    if (!AI) {
      // No live model (e.g. self-hosted): fall back to a pre-written sample draft.
      if (demo && demo.draft) return { escalated: null, text: demo.draft, demo: true };
      return { escalated: null, text: "", error: "Live AI isn't available in this hosted demo — run it in an AI-enabled environment to generate drafts. (Escalation, retrieval and the workflow all still work.)" };
    }

    const context = hits.length
      ? hits.map(h => `[${h.doc}] ${h.text}`).join("\n\n")
      : "(No matching content retrieved from the CS knowledge base.)";

    const userMsg = `<retrieved_context>\n${context}\n</retrieved_context>\n\nCustomer message: "${message}"\n\nDraft the agent's reply.`;

    try {
      const text = await window.claude.complete({
        system: SYSTEM_PROMPT,
        max_tokens: 400,
        messages: [{ role: "user", content: userMsg }]
      });
      return { escalated: null, text: (text || "").trim() };
    } catch (e) {
      return { escalated: null, text: "", error: (e && e.message) || "The assist model is unavailable right now. Try again in a moment." };
    }
  }

  window.Assist = { retrieve, classify, draft, tokenize, SYSTEM_PROMPT };
})();
