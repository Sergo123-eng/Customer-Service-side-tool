# Agent Assist — AI copilot for customer support

A working prototype of an **AI Agent Assist** tool for a customer-service team. When a
ticket comes in, the tool retrieves the relevant policy docs from a knowledge base (RAG),
drafts a grounded, on-brand reply for the agent to review, and hard-escalates
safety-critical or high-tension conversations to a human.

## Features
- **RAG retrieval** — transparent keyword/tag scoring over a policy knowledge base, with
  per-source match scores so you can see *why* each doc was pulled.
- **Grounded drafting** — replies are generated only from retrieved context and cite their
  source document; the model never invents policy.
- **Safety guardrails** — mechanical / gas / electrical questions auto-transfer to a
  technician; angry or commercial-dispute customers route to a manager. No AI answer is sent.
- **Polish & align** — write a reply in your own words and the AI rewrites it in brand voice
  while preserving every specific you included.
- **Sentiment-aware customer simulation** — after you reply, the customer writes back with a
  thank-you (positive) or a follow-up question (negative), tagged with its sentiment.
- **Agent controls** — tickets stay open until you explicitly Close (or Reopen) them.
- **QA log** — every AI suggestion and agent decision (accepted / edited / polished /
  dismissed / escalated) is logged for review.
- **Tweaks panel** — switch the assist layout (rail / focus / drawer), accent color, and density.

## Run it
It's plain static files — no build step. Either:
- open `index.html` with a local server (e.g. `python3 -m http.server`), or
- host the folder on **GitHub Pages** (Settings → Pages → deploy from branch → root).

### About the AI
The live drafting/polish/customer-reply features call an AI helper (`window.claude`) that is
only present in the authoring environment. When that helper isn't available (e.g. on GitHub
Pages) the app automatically runs in **Demo mode**, using pre-written sample responses for the
built-in tickets so the full workflow still works with **no API key**. To wire it to a real
model, replace the `window.claude.complete` calls in `assist-engine.js` / `app.jsx` with your
own backend endpoint (keep the key server-side).

## Files
- `index.html` — app shell, styling, script loading
- `kb-data.js` — knowledge base, sample tickets, FAQ, demo fallbacks
- `assist-engine.js` — retrieval + drafting logic and the system prompt
- `ui.jsx` — presentational components
- `app.jsx` — main React app
- `tweaks-panel.jsx` — the Tweaks control panel

Built as a design/prototype exercise. React + Babel (in-browser), no dependencies to install.
